<?php
/**
 * Plugin Name:    	shopmarket Extensions
 * Plugin URI:     	https://themeforest.net/user/themefushion/portfolio
 * Description:    	This selection of extensions compliment our lean and mean theme for WooCommerce, shopmarket. Please note: they don’t work with any WordPress theme, just shopmarket.
 * Author:         	themefushion
 * Author URI:     	https://themeforest.net/user/themefushion
 * Version:        	1.4.17
 * Text Domain: 	shopmarket-extensions
 * Domain Path: 	/languages
 * WC tested up to: 4.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( ! class_exists( 'shopmarket_Extensions' ) ) {
	/**
	 * Main shopmarket_Extensions Class
	 *
	 * @class shopmarket_Extensions
	 * @version	1.0.0
	 * @since 1.0.0
	 * @package	Kudos
	 * @author Ibrahim
	 */
	final class shopmarket_Extensions {
		/**
		 * shopmarket_Extensions The single instance of shopmarket_Extensions.
		 * @var 	object
		 * @access  private
		 * @since 	1.0.0
		 */
		private static $_instance = null;

		/**
		 * The token.
		 * @var     string
		 * @access  public
		 * @since   1.0.0
		 */
		public $token;

		/**
		 * The version number.
		 * @var     string
		 * @access  public
		 * @since   1.0.0
		 */
		public $version;

		/**
		 * Constructor function.
		 * @access  public
		 * @since   1.0.0
		 * @return  void
		 */
		public function __construct () {
			
			$this->token 	= 'shopmarket-extensions';
			$this->version 	= '1.0.0';
			
			add_action( 'plugins_loaded', array( $this, 'setup_constants' ),		10 );
			add_action( 'plugins_loaded', array( $this, 'includes' ),				20 );
			add_action( 'plugins_loaded', array( $this, 'load_plugin_textdomain' ),	30 );
		}

		/**
		 * Main shopmarket_Extensions Instance
		 *
		 * Ensures only one instance of shopmarket_Extensions is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 * @static
		 * @see shopmarket_Extensions()
		 * @return Main Kudos instance
		 */
		public static function instance () {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}

		/**
		 * Setup plugin constants
		 *
		 * @access public
		 * @since  1.0.0
		 * @return void
		 */
		public function setup_constants() {

			// Plugin Folder Path
			if ( ! defined( 'shopmarket_EXTENSIONS_DIR' ) ) {
				define( 'shopmarket_EXTENSIONS_DIR', plugin_dir_path( __FILE__ ) );
			}

			// Plugin Folder URL
			if ( ! defined( 'shopmarket_EXTENSIONS_URL' ) ) {
				define( 'shopmarket_EXTENSIONS_URL', plugin_dir_url( __FILE__ ) );
			}

			// Plugin Root File
			if ( ! defined( 'shopmarket_EXTENSIONS_FILE' ) ) {
				define( 'shopmarket_EXTENSIONS_FILE', __FILE__ );
			}

			// Modules File
			if ( ! defined( 'shopmarket_MODULES_DIR' ) ) {
				define( 'shopmarket_MODULES_DIR', shopmarket_EXTENSIONS_DIR . '/modules' );
			}
		}

		/**
		 * Include required files
		 *
		 * @access public
		 * @since  1.0.0
		 * @return void
		 */
		public function includes() {

			#-----------------------------------------------------------------
			# Post Formats
			#-----------------------------------------------------------------
			require_once shopmarket_MODULES_DIR . '/post-formats/post-formats.php';

			#-----------------------------------------------------------------
			# Static Block Post Type
			#-----------------------------------------------------------------
			require_once shopmarket_MODULES_DIR . '/post-types/static-block/static-block.php';

			#-----------------------------------------------------------------
			# Theme Shortcodes
			#-----------------------------------------------------------------
			require_once shopmarket_MODULES_DIR . '/theme-shortcodes/theme-shortcodes.php';

			#-----------------------------------------------------------------
			# King Composer Extensions
			#-----------------------------------------------------------------
			require_once shopmarket_MODULES_DIR . '/kingcomposer/kingcomposer.php';

			#-----------------------------------------------------------------
			# Visual Composer Extensions
			#-----------------------------------------------------------------
			require_once shopmarket_MODULES_DIR . '/js_composer/js_composer.php';

			#-----------------------------------------------------------------
			# Elementor Extensions
			#-----------------------------------------------------------------
			require_once shopmarket_MODULES_DIR . '/elementor/elementor.php';
		}

		/**
		 * Load the localisation file.
		 * @access  public
		 * @since   1.0.0
		 * @return  void
		 */
		public function load_plugin_textdomain() {
			load_plugin_textdomain( 'shopmarket-extensions', false, dirname( plugin_basename( shopmarket_EXTENSIONS_FILE ) ) . '/languages/' );
		}

		/**
		 * Cloning is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __clone () {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'shopmarket-extensions' ), '1.0.0' );
		}

		/**
		 * Unserializing instances of this class is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __wakeup () {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'shopmarket-extensions' ), '1.0.0' );
		}
	}
}

/**
 * Returns the main instance of shopmarket_Extensions to prevent the need to use globals.
 *
 * @since  1.0.0
 * @return object shopmarket_Extensions
 */
function shopmarket_Extensions() {
	return shopmarket_Extensions::instance();
}

/**
 * Initialise the plugin
 */
shopmarket_Extensions();