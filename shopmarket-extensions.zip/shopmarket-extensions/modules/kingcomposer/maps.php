<?php

if( ! defined('KC_FILE' ) ) {
	header('HTTP/1.0 403 Forbidden');
	exit;
}

$kc = KingComposer::globe();

$shortcode_params = array();

$shortcode_params['shopmarket_3_2_3_product_cards_tab_with_featured_product'] = array(
	'name' => esc_html__( '3-2-3 Products Cards Tabs', 'shopmarket-extensions' ),
	'description' => esc_html__( '3-2-3 Products Cards Tabs', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( '3-2-3 Products Cards Tabs Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'section_title',
			'label'			=> esc_html__('Section Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'description'	=> esc_html__('Enter section title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'default_active_tab',
			'label'			=> esc_html__('Default Active Tab', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter default active tab id.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Tabs', 'shopmarket-extensions' ),
			'name'			=> 'tabs',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new tab', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'title',
					'label'			=> esc_html__('Title', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'shortcode_tag',
					'label'			=> esc_html__( 'Shortcode', 'shopmarket-extensions' ),
					'type'			=> 'select',
					'options'		=> array(
						'featured_products'		=> esc_html__( 'Featured Products','shopmarket-extensions'),
						'sale_products'			=> esc_html__( 'On Sale Products','shopmarket-extensions'),
						'top_rated_products'	=> esc_html__( 'Top Rated Products','shopmarket-extensions'),
						'recent_products'		=> esc_html__( 'Recent Products','shopmarket-extensions'),
						'best_selling_products'	=> esc_html__( 'Best Selling Products','shopmarket-extensions'),
						'products'				=> esc_html__( 'Products','shopmarket-extensions'),
						'product_category'		=> esc_html__( 'Product Category','shopmarket-extensions')
					),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'orderby',
					'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
					'value'			=> 'date',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'order',
					'label'			=> esc_html__('Order', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
					'value'			=> 'desc',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'product_id',
					'label'			=> esc_html__('Product IDs', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with Products Shortcode.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'category',
					'label'			=> esc_html__('Category', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter slug spearate by comma(,) Note: Only works with Product Category Shortcode.', 'shopmarket-extensions'),
					'admin_label'	=> true
				)
			)
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_6_1_6_tabs_with_deals'] = array(
	'name' => esc_html__( '6-1-6 Products Tabs with Deals', 'shopmarket-extensions' ),
	'description' => esc_html__( '6-1-6 Products Tabs with Deals', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( '6-1-6 Products Tabs with Deals Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'section_title',
			'label'			=> esc_html__('Section Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'description'	=> esc_html__('Enter section title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Tabs', 'shopmarket-extensions' ),
			'name'			=> 'tabs',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new tab', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'title',
					'label'			=> esc_html__('Title', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'shortcode_tag',
					'label'			=> esc_html__( 'Shortcode', 'shopmarket-extensions' ),
					'type'			=> 'select',
					'options'		=> array(
						'featured_products'		=> esc_html__( 'Featured Products','shopmarket-extensions'),
						'sale_products'			=> esc_html__( 'On Sale Products','shopmarket-extensions'),
						'top_rated_products'	=> esc_html__( 'Top Rated Products','shopmarket-extensions'),
						'recent_products'		=> esc_html__( 'Recent Products','shopmarket-extensions'),
						'best_selling_products'	=> esc_html__( 'Best Selling Products','shopmarket-extensions'),
						'products'				=> esc_html__( 'Products','shopmarket-extensions'),
						'product_category'		=> esc_html__( 'Product Category','shopmarket-extensions')
					),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'orderby',
					'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
					'value'			=> 'date',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'order',
					'label'			=> esc_html__('Order', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
					'value'			=> 'desc',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'product_id',
					'label'			=> esc_html__('Product IDs', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with Products Shortcode.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'category',
					'label'			=> esc_html__('Category', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter slug spearate by comma(,) Note: Only works with Product Category Shortcode.', 'shopmarket-extensions'),
					'admin_label'	=> true
				)
			)
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_banner'] = array(
	'name' => esc_html__( 'Banner', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Banner', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Banner Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'bg_choice',
			'label'			=> esc_html__( 'Background Choice', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'image'			=> esc_html__('Image', 'shopmarket-extensions'),
				'color'			=> esc_html__('Color', 'shopmarket-extensions')
			),
			'description'	=> esc_html__( 'Select choice for background.', 'shopmarket-extensions' ),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'bg_image',
			'type'			=> 'attach_image',
			'label'			=> esc_html__( 'Background Image', 'shopmarket-extensions' ),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'bg_color',
			'label'			=> esc_html__( 'Background Color', 'shopmarket-extensions' ),
			'type'			=> 'color_picker',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'bg_height',
			'label'			=> esc_html__('Height', 'shopmarket-extensions'),
			'type'			=> 'text',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'pre_title',
			'label'			=> esc_html__('Pre Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'sub_title',
			'label'			=> esc_html__('Sub Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'action_text',
			'label'			=> esc_html__('Action Text', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'action_link',
			'label'			=> esc_html__('Action Link', 'shopmarket-extensions'),
			'type'			=> 'text',
			'value'			=> '#',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'price',
			'label'			=> esc_html__('Price', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_banners'] = array(
	'name' => esc_html__( 'Banners', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Banners', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Banners Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Banners', 'shopmarket-extensions' ),
			'name'			=> 'banners',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new banner', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'bg_choice',
					'label'			=> esc_html__( 'Background Choice', 'shopmarket-extensions' ),
					'type'			=> 'select',
					'options'		=> array(
						'image'			=> esc_html__('Image', 'shopmarket-extensions'),
						'color'			=> esc_html__('Color', 'shopmarket-extensions')
					),
					'description'	=> esc_html__( 'Select choice for background.', 'shopmarket-extensions' ),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'bg_image',
					'type'			=> 'attach_image',
					'label'			=> esc_html__( 'Background Image', 'shopmarket-extensions' ),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'bg_color',
					'label'			=> esc_html__( 'Background Color', 'shopmarket-extensions' ),
					'type'			=> 'color_picker',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'bg_height',
					'label'			=> esc_html__('Height', 'shopmarket-extensions'),
					'type'			=> 'text',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'pre_title',
					'label'			=> esc_html__('Pre Title', 'shopmarket-extensions'),
					'type'			=> 'textarea',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'title',
					'label'			=> esc_html__('Title', 'shopmarket-extensions'),
					'type'			=> 'textarea',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'sub_title',
					'label'			=> esc_html__('Sub Title', 'shopmarket-extensions'),
					'type'			=> 'textarea',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'action_text',
					'label'			=> esc_html__('Action Text', 'shopmarket-extensions'),
					'type'			=> 'textarea',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'action_link',
					'label'			=> esc_html__('Action Link', 'shopmarket-extensions'),
					'type'			=> 'text',
					'value'			=> '#',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'price',
					'label'			=> esc_html__('Price', 'shopmarket-extensions'),
					'type'			=> 'textarea',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'section_class',
					'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
				)
			)
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_brands_carousel'] = array(
	'name' => esc_html__( 'Brands Carousel', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Brands Carousel', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Brands Carousel Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'limit',
			'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of brands to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'orderby',
			'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
			'value'			=> 'date',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'order',
			'label'			=> esc_html__('Order', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
			'value'			=> 'desc',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'include',
			'label'			=> esc_html__('Include', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter id spearate by comma(,)', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Hide Empty?', 'shopmarket-extensions' ),
			'name'			=> 'hide_empty',
			'description'	=> esc_html__( 'Check to hide empty brands.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'ca_slidestoshow',
			'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidestoscroll',
			'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Responsive', 'shopmarket-extensions' ),
			'name'			=> 'ca_responsive',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new breakpoint', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'ca_res_breakpoint',
					'label'			=> esc_html__('Breakpoint', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter breakpoint.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoshow',
					'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoscroll',
					'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
					'admin_label'	=> true
				)
			)
		)
	),
);

$shortcode_params['shopmarket_brands'] = array(
	'name' => esc_html__( 'Brands', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Brands', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Brands Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'limit',
			'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of brands to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'orderby',
			'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
			'value'			=> 'date',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'order',
			'label'			=> esc_html__('Order', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
			'value'			=> 'desc',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'include',
			'label'			=> esc_html__('Include', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter id spearate by comma(,)', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Hide Empty?', 'shopmarket-extensions' ),
			'name'			=> 'hide_empty',
			'description'	=> esc_html__( 'Check to hide empty brands.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		)
	),
);

$shortcode_params['shopmarket_deals_cards_carousel_with_gallery'] = array(
	'name' => esc_html__( 'Deals Cards Carousel with Gallery', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Deals Cards Carousel with Gallery', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Deals Cards Carousel with Gallery Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'shortcode_tag',
			'label'			=> esc_html__( 'Shortcode', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'featured_products'		=> esc_html__( 'Featured Products','shopmarket-extensions'),
				'sale_products'			=> esc_html__( 'On Sale Products','shopmarket-extensions'),
				'top_rated_products'	=> esc_html__( 'Top Rated Products','shopmarket-extensions'),
				'recent_products'		=> esc_html__( 'Recent Products','shopmarket-extensions'),
				'best_selling_products'	=> esc_html__( 'Best Selling Products','shopmarket-extensions'),
				'products'				=> esc_html__( 'Products','shopmarket-extensions'),
				'product_category'		=> esc_html__( 'Product Category','shopmarket-extensions')
			),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'per_page',
			'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of products to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'orderby',
			'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
			'value'			=> 'date',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'order',
			'label'			=> esc_html__('Order', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
			'value'			=> 'desc',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'product_id',
			'label'			=> esc_html__('Product IDs', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with Products Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'category',
			'label'			=> esc_html__('Category', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter slug spearate by comma(,) Note: Only works with Product Category Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Infinite?', 'shopmarket-extensions' ),
			'name'			=> 'ca_infinite',
			'description'	=> esc_html__( 'Check to show Infinite Carousel.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Dots?', 'shopmarket-extensions' ),
			'name'			=> 'ca_dots',
			'description'	=> esc_html__( 'Check to show Dots.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Arrows?', 'shopmarket-extensions' ),
			'name'			=> 'ca_arrows',
			'description'	=> esc_html__( 'Check to show Arrows.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_deals_cards_carousel'] = array(
	'name' => esc_html__( 'Deals Cards Carousel', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Deals Cards Carousel', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Deals Cards Carousel Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'shortcode_tag',
			'label'			=> esc_html__( 'Shortcode', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'featured_products'		=> esc_html__( 'Featured Products','shopmarket-extensions'),
				'sale_products'			=> esc_html__( 'On Sale Products','shopmarket-extensions'),
				'top_rated_products'	=> esc_html__( 'Top Rated Products','shopmarket-extensions'),
				'recent_products'		=> esc_html__( 'Recent Products','shopmarket-extensions'),
				'best_selling_products'	=> esc_html__( 'Best Selling Products','shopmarket-extensions'),
				'products'				=> esc_html__( 'Products','shopmarket-extensions'),
				'product_category'		=> esc_html__( 'Product Category','shopmarket-extensions')
			),
			'value'			=> 'sale_products',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'per_page',
			'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of products to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'orderby',
			'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
			'value'			=> 'date',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'order',
			'label'			=> esc_html__('Order', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
			'value'			=> 'desc',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'product_id',
			'label'			=> esc_html__('Product IDs', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with Products Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'category',
			'label'			=> esc_html__('Category', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter slug spearate by comma(,) Note: Only works with Product Category Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Header Navigation?', 'shopmarket-extensions' ),
			'name'			=> 'header_custom_nav',
			'description'	=> esc_html__( 'Check to show Custom Navigation.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Header Timer?', 'shopmarket-extensions' ),
			'name'			=> 'header_timer',
			'description'	=> esc_html__( 'Check to show Header Timer.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'timer_value',
			'label'			=> esc_html__('Timer Value', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the timer value.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidestoshow',
			'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
			'value'			=> 2,
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidestoscroll',
			'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
			'value'			=> 2,
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Dots?', 'shopmarket-extensions' ),
			'name'			=> 'ca_dots',
			'description'	=> esc_html__( 'Check to show Dots.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Responsive', 'shopmarket-extensions' ),
			'name'			=> 'ca_responsive',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new breakpoint', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'ca_res_breakpoint',
					'label'			=> esc_html__('Breakpoint', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter breakpoint.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoshow',
					'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoscroll',
					'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
					'admin_label'	=> true
				)
			)
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_deals_carousel'] = array(
	'name' => esc_html__( 'Deals Carousel', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Deals Carousel', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Deals Carousel Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'shortcode_tag',
			'label'			=> esc_html__( 'Shortcode', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'featured_products'		=> esc_html__( 'Featured Products','shopmarket-extensions'),
				'sale_products'			=> esc_html__( 'On Sale Products','shopmarket-extensions'),
				'top_rated_products'	=> esc_html__( 'Top Rated Products','shopmarket-extensions'),
				'recent_products'		=> esc_html__( 'Recent Products','shopmarket-extensions'),
				'best_selling_products'	=> esc_html__( 'Best Selling Products','shopmarket-extensions'),
				'products'				=> esc_html__( 'Products','shopmarket-extensions'),
				'product_category'		=> esc_html__( 'Product Category','shopmarket-extensions')
			),
			'value'			=> 'sale_products',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'per_page',
			'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of products to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'orderby',
			'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
			'value'			=> 'date',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'order',
			'label'			=> esc_html__('Order', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
			'value'			=> 'desc',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'product_id',
			'label'			=> esc_html__('Product IDs', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with Products Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'category',
			'label'			=> esc_html__('Category', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter slug spearate by comma(,) Note: Only works with Product Category Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Header Navigation?', 'shopmarket-extensions' ),
			'name'			=> 'header_custom_nav',
			'description'	=> esc_html__( 'Check to show Custom Navigation.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_features_list'] = array(
	'name' => esc_html__( 'Features List', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Features List', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Features List Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Features', 'shopmarket-extensions' ),
			'name'			=> 'features',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new feature', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'icon',
					'label'			=> esc_html__('Icon', 'shopmarket-extensions'),
					'type'			=> 'icon_picker',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'label',
					'label'			=> esc_html__('Label', 'shopmarket-extensions'),
					'type'			=> 'textarea',
					'admin_label'	=> true
				)
			)
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_fullwidth_notice'] = array(
	'name' => esc_html__( 'Notice', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Notice', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Notice Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'notice_info',
			'label'			=> esc_html__('Text', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_jumbotron'] = array(
	'name' => esc_html__( 'Jumbotron', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Add Jumbotron to your page.', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Jumbotron Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'sub_title',
			'label'			=> esc_html__('Sub Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'image',
			'type'			=> 'attach_image',
			'label'			=> esc_html__( 'Background Image', 'shopmarket-extensions' ),
			'admin_label'	=> true
		)
	),
);

$shortcode_params['shopmarket_media_single_banner'] = array(
	'name' => esc_html__( 'Media Single Banner', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Media Single Banner', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Media Single Banner Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'section_title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'description',
			'label'			=> esc_html__('Description', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'action_text',
			'label'			=> esc_html__('Action Text', 'shopmarket-extensions'),
			'type'			=> 'text',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'action_link',
			'label'			=> esc_html__('Action Link', 'shopmarket-extensions'),
			'type'			=> 'text',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'image',
			'type'			=> 'attach_image',
			'label'			=> esc_html__( 'Image', 'shopmarket-extensions' ),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'media_align',
			'label'			=> esc_html__( 'Media Align', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'media-left'			=> esc_html__( 'Left','shopmarket-extensions'),
				'media-right'			=> esc_html__( 'Rignt','shopmarket-extensions')
			),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_poster'] = array(
	'name' => esc_html__( 'Poster', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Poster', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Poster Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'bg_choice',
			'label'			=> esc_html__( 'Background Choice', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'image'			=> esc_html__('Image', 'shopmarket-extensions'),
				'color'			=> esc_html__('Color', 'shopmarket-extensions')
			),
			'description'	=> esc_html__( 'Select choice for background.', 'shopmarket-extensions' ),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'bg_image',
			'type'			=> 'attach_image',
			'label'			=> esc_html__( 'Background Image', 'shopmarket-extensions' ),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'bg_color',
			'label'			=> esc_html__( 'Background Color', 'shopmarket-extensions' ),
			'type'			=> 'color_picker',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'bg_height',
			'label'			=> esc_html__('Height', 'shopmarket-extensions'),
			'type'			=> 'text',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'pre_title',
			'label'			=> esc_html__('Pre Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'sub_title',
			'label'			=> esc_html__('Sub Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'action_text',
			'label'			=> esc_html__('Action Text', 'shopmarket-extensions'),
			'type'			=> 'text',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'action_link',
			'label'			=> esc_html__('Action Link', 'shopmarket-extensions'),
			'type'			=> 'text',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'condition',
			'label'			=> esc_html__('Condition', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_product_card_carousel_with_gallery'] = array(
	'name' => esc_html__( 'Products Cards Carousel with Gallery', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Products Cards Carousel with Gallery', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Products Cards Carousel with Gallery Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'shortcode_tag',
			'label'			=> esc_html__( 'Shortcode', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'featured_products'		=> esc_html__( 'Featured Products','shopmarket-extensions'),
				'sale_products'			=> esc_html__( 'On Sale Products','shopmarket-extensions'),
				'top_rated_products'	=> esc_html__( 'Top Rated Products','shopmarket-extensions'),
				'recent_products'		=> esc_html__( 'Recent Products','shopmarket-extensions'),
				'best_selling_products'	=> esc_html__( 'Best Selling Products','shopmarket-extensions'),
				'products'				=> esc_html__( 'Products','shopmarket-extensions'),
				'product_category'		=> esc_html__( 'Product Category','shopmarket-extensions')
			),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'per_page',
			'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of products to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'orderby',
			'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
			'value'			=> 'date',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'order',
			'label'			=> esc_html__('Order', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
			'value'			=> 'desc',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'product_id',
			'label'			=> esc_html__('Product IDs', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with Products Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'category',
			'label'			=> esc_html__('Category', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter slug spearate by comma(,) Note: Only works with Product Category Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Infinite?', 'shopmarket-extensions' ),
			'name'			=> 'ca_infinite',
			'description'	=> esc_html__( 'Check to show Infinite Carousel.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Dots?', 'shopmarket-extensions' ),
			'name'			=> 'ca_dots',
			'description'	=> esc_html__( 'Check to show Dots.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Arrows?', 'shopmarket-extensions' ),
			'name'			=> 'ca_arrows',
			'description'	=> esc_html__( 'Check to show Arrows.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_product_categories_carousel'] = array(
	'name' => esc_html__( 'Products Categories Carousel', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Products Categories Carousel', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Products Categories Carousel Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'pre_title',
			'label'			=> esc_html__('Pre Title', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter pre title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'section_title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Header Navigation?', 'shopmarket-extensions' ),
			'name'			=> 'header_custom_nav',
			'description'	=> esc_html__( 'Check to show Custom Navigation.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'limit',
			'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of products to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'button_text',
			'label'			=> esc_html__('Button Text', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the button text.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'button_link',
			'label'			=> esc_html__('Button Link', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the button link.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'orderby',
			'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
			'value'			=> 'date',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'order',
			'label'			=> esc_html__('Order', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
			'value'			=> 'desc',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'include',
			'label'			=> esc_html__('Include', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter slugs spearate by comma(,)', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Hide Empty?', 'shopmarket-extensions' ),
			'name'			=> 'hide_empty',
			'description'	=> esc_html__( 'Check to hide empty products.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'ca_slidestoshow',
			'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidestoscroll',
			'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Responsive', 'shopmarket-extensions' ),
			'name'			=> 'ca_responsive',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new breakpoint', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'ca_res_breakpoint',
					'label'			=> esc_html__('Breakpoint', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter breakpoint.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoshow',
					'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoscroll',
					'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
					'admin_label'	=> true
				)
			)
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_product_categories_filter'] = array(
	'name' => esc_html__( 'Product Categories Filter', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Product Categories Filter', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Product Categories Filter Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'per_page',
			'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of products to display.', 'shopmarket-extensions'),
			'value'			=> 8,
			'admin_label'	=> true
		),
		array(
			'name'			=> 'columns',
			'label'			=> esc_html__('Columns', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of columns to display.', 'shopmarket-extensions'),
			'value'			=> 4,
			'admin_label'	=> true
		),
		array(
			'name'			=> 'orderby',
			'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
			'value'			=> 'date',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'order',
			'label'			=> esc_html__('Order', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
			'value'			=> 'desc',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'template',
			'label'			=> esc_html__('Template', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter template.', 'shopmarket-extensions'),
			'value'			=> 'content-product-featured',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'cat_show_all_text',
			'label'			=> esc_html__('Category show all text', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter Category show all option text', 'shopmarket-extensions'),
			'value'			=> esc_html__( 'All Categories', 'shopmarket-extensions' ),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Hide Empty?', 'shopmarket-extensions' ),
			'name'			=> 'cat_hide_if_empty',
			'description'	=> esc_html__( 'Check to hide empty categories.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'cat_include',
			'label'			=> esc_html__('Include', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter category slugs spearate by comma(,)', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_product_categories_list'] = array(
	'name' => esc_html__( 'Products Categories List', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Products Categories List', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Products Categories List Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'section_title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'limit',
			'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of products to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'orderby',
			'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
			'value'			=> 'date',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'order',
			'label'			=> esc_html__('Order', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
			'value'			=> 'desc',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'include',
			'label'			=> esc_html__('Include', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter slugs spearate by comma(,)', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'parent',
			'label'			=> esc_html__('Parent', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter parent category id. Use 0 for list first level categories only.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Hide Empty?', 'shopmarket-extensions' ),
			'name'			=> 'hide_empty',
			'description'	=> esc_html__( 'Check to hide empty products.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		)
	),
);

$shortcode_params['shopmarket_products_cards_carousel_with_bg'] = array(
	'name' => esc_html__( 'Products Cards Carousel with Image', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Products Cards Carousel with Image', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Products Cards Carousel with Image Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'shortcode_tag',
			'label'			=> esc_html__( 'Shortcode', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'featured_products'		=> esc_html__( 'Featured Products','shopmarket-extensions'),
				'sale_products'			=> esc_html__( 'On Sale Products','shopmarket-extensions'),
				'top_rated_products'	=> esc_html__( 'Top Rated Products','shopmarket-extensions'),
				'recent_products'		=> esc_html__( 'Recent Products','shopmarket-extensions'),
				'best_selling_products'	=> esc_html__( 'Best Selling Products','shopmarket-extensions'),
				'products'				=> esc_html__( 'Products','shopmarket-extensions'),
				'product_category'		=> esc_html__( 'Product Category','shopmarket-extensions')
			),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'per_page',
			'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of products to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'orderby',
			'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
			'value'			=> 'date',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'order',
			'label'			=> esc_html__('Order', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
			'value'			=> 'desc',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'product_id',
			'label'			=> esc_html__('Product IDs', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with Products Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'category',
			'label'			=> esc_html__('Category', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter slug spearate by comma(,) Note: Only works with Product Category Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'image',
			'type'			=> 'attach_image',
			'label'			=> esc_html__( 'Image', 'shopmarket-extensions' ),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Infinite?', 'shopmarket-extensions' ),
			'name'			=> 'ca_infinite',
			'description'	=> esc_html__( 'Check to show Infinite Carousel.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'ca_rows',
			'label'			=> esc_html__('rows', 'shopmarket-extensions'),
			'type'			=> 'text',
			'value'			=> 2,
			'description'	=> esc_html__('Enter the number of rows to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidesperrow',
			'label'			=> esc_html__('slidesPerRow', 'shopmarket-extensions'),
			'type'			=> 'text',
			'value'			=> 2,
			'description'	=> esc_html__('Enter the number of items to display in a row.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidestoshow',
			'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
			'type'			=> 'text',
			'value'			=> 1,
			'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidestoscroll',
			'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
			'type'			=> 'text',
			'value'			=> 1,
			'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Dots?', 'shopmarket-extensions' ),
			'name'			=> 'ca_dots',
			'description'	=> esc_html__( 'Check to show Dots.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Arrows?', 'shopmarket-extensions' ),
			'name'			=> 'ca_arrows',
			'description'	=> esc_html__( 'Check to show Arrows.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Responsive', 'shopmarket-extensions' ),
			'name'			=> 'ca_responsive',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new breakpoint', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'ca_res_breakpoint',
					'label'			=> esc_html__('Breakpoint', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter breakpoint.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidesperrow',
					'label'			=> esc_html__('slidesPerRow', 'shopmarket-extensions'),
					'type'			=> 'text',
					'value'			=> 1,
					'description'	=> esc_html__('Enter the number of items to display in a row.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoshow',
					'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoscroll',
					'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
					'admin_label'	=> true
				)
			)
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_products_carousel_tabs_with_featured_product'] = array(
	'name' => esc_html__( 'Products Carousel Tabs with Featured Product', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Products Carousel Tabs with Featured Product', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Products Carousel Tabs with Featured Product Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'section_title',
			'label'			=> esc_html__('Section Title', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter section title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'header_nav_align',
			'label'			=> esc_html__( 'Header Align', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'justify-content-start'		=> esc_html__( 'Start', 'shopmarket-extensions'),
				'justify-content-center'	=> esc_html__( 'Center', 'shopmarket-extensions'),
				'justify-content-end'		=> esc_html__( 'End', 'shopmarket-extensions'),
			),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Tabs', 'shopmarket-extensions' ),
			'name'			=> 'tabs',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new tab', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'title',
					'label'			=> esc_html__('Title', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'shortcode_tag',
					'label'			=> esc_html__( 'Shortcode', 'shopmarket-extensions' ),
					'type'			=> 'select',
					'options'		=> array(
						'featured_products'		=> esc_html__( 'Featured Products','shopmarket-extensions'),
						'sale_products'			=> esc_html__( 'On Sale Products','shopmarket-extensions'),
						'top_rated_products'	=> esc_html__( 'Top Rated Products','shopmarket-extensions'),
						'recent_products'		=> esc_html__( 'Recent Products','shopmarket-extensions'),
						'best_selling_products'	=> esc_html__( 'Best Selling Products','shopmarket-extensions'),
						'products'				=> esc_html__( 'Products','shopmarket-extensions'),
						'product_category'		=> esc_html__( 'Product Category','shopmarket-extensions')
					),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'per_page',
					'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of products to display.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'orderby',
					'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
					'value'			=> 'date',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'order',
					'label'			=> esc_html__('Order', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
					'value'			=> 'desc',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'template',
					'label'			=> esc_html__('Template', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter product template Default: content-product', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'product_id',
					'label'			=> esc_html__('Product IDs', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with Products Shortcode.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'category',
					'label'			=> esc_html__('Category', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter slug spearate by comma(,) Note: Only works with Product Category Shortcode.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'featured_shortcode_tag',
					'label'			=> esc_html__( 'Shortcode Featured', 'shopmarket-extensions' ),
					'type'			=> 'select',
					'options'		=> array(
						'featured_products'		=> esc_html__( 'Featured Products','shopmarket-extensions'),
						'sale_products'			=> esc_html__( 'On Sale Products','shopmarket-extensions'),
						'top_rated_products'	=> esc_html__( 'Top Rated Products','shopmarket-extensions'),
						'recent_products'		=> esc_html__( 'Recent Products','shopmarket-extensions'),
						'best_selling_products'	=> esc_html__( 'Best Selling Products','shopmarket-extensions'),
						'products'				=> esc_html__( 'Products','shopmarket-extensions'),
						'product_category'		=> esc_html__( 'Product Category','shopmarket-extensions')
					),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'featured_product_id',
					'label'			=> esc_html__('Product IDs Featured', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with Products Shortcode.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'featured_category',
					'label'			=> esc_html__('Category Featured', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter slug spearate by comma(,) Note: Only works with Product Category Shortcode.', 'shopmarket-extensions'),
					'admin_label'	=> true
				)
			)
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Infinite?', 'shopmarket-extensions' ),
			'name'			=> 'ca_infinite',
			'description'	=> esc_html__( 'Check to show Infinite Carousel.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'ca_rows',
			'label'			=> esc_html__('rows', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of rows to display.', 'shopmarket-extensions'),
			'value'			=> 2,
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidesperrow',
			'label'			=> esc_html__('slidesPerRow', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to display in a row.', 'shopmarket-extensions'),
			'value'			=> 6,
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidestoshow',
			'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
			'value'			=> 1,
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidestoscroll',
			'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
			'value'			=> 1,
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Dots?', 'shopmarket-extensions' ),
			'name'			=> 'ca_dots',
			'description'	=> esc_html__( 'Check to show Dots.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Arrows?', 'shopmarket-extensions' ),
			'name'			=> 'ca_arrows',
			'description'	=> esc_html__( 'Check to show Arrows.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Responsive', 'shopmarket-extensions' ),
			'name'			=> 'ca_responsive',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new breakpoint', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'ca_res_breakpoint',
					'label'			=> esc_html__('Breakpoint', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter breakpoint.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidesperrow',
					'label'			=> esc_html__('slidesPerRow', 'shopmarket-extensions'),
					'type'			=> 'text',
					'value'			=> 1,
					'description'	=> esc_html__('Enter the number of items to display in a row.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoshow',
					'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoscroll',
					'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
					'admin_label'	=> true
				)
			)
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_products_carousel_tabs'] = array(
	'name' => esc_html__( 'Products Carousel Tabs', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Products Carousel Tabs', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Products Carousel Tabs Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'section_title',
			'label'			=> esc_html__('Section Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'description'	=> esc_html__('Enter section title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'header_nav_align',
			'label'			=> esc_html__( 'Header Align', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'justify-content-start'		=> esc_html__( 'Start', 'shopmarket-extensions'),
				'justify-content-center'	=> esc_html__( 'Center', 'shopmarket-extensions'),
				'justify-content-end'		=> esc_html__( 'End', 'shopmarket-extensions'),
			),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Tabs', 'shopmarket-extensions' ),
			'name'			=> 'tabs',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new tab', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'title',
					'label'			=> esc_html__('Title', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'shortcode_tag',
					'label'			=> esc_html__( 'Shortcode', 'shopmarket-extensions' ),
					'type'			=> 'select',
					'options'		=> array(
						'featured_products'		=> esc_html__( 'Featured Products','shopmarket-extensions'),
						'sale_products'			=> esc_html__( 'On Sale Products','shopmarket-extensions'),
						'top_rated_products'	=> esc_html__( 'Top Rated Products','shopmarket-extensions'),
						'recent_products'		=> esc_html__( 'Recent Products','shopmarket-extensions'),
						'best_selling_products'	=> esc_html__( 'Best Selling Products','shopmarket-extensions'),
						'products'				=> esc_html__( 'Products','shopmarket-extensions'),
						'product_category'		=> esc_html__( 'Product Category','shopmarket-extensions')
					),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'per_page',
					'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of products to display.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'orderby',
					'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
					'value'			=> 'date',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'order',
					'label'			=> esc_html__('Order', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
					'value'			=> 'desc',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'template',
					'label'			=> esc_html__('Template', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter product template Default: content-product', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'product_id',
					'label'			=> esc_html__('Product IDs', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with Products Shortcode.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'category',
					'label'			=> esc_html__('Category', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter slug spearate by comma(,) Note: Only works with Product Category Shortcode.', 'shopmarket-extensions'),
					'admin_label'	=> true
				)
			)
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Infinite?', 'shopmarket-extensions' ),
			'name'			=> 'ca_infinite',
			'description'	=> esc_html__( 'Check to show Infinite Carousel.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'ca_rows',
			'label'			=> esc_html__('rows', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of rows to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidesperrow',
			'label'			=> esc_html__('slidesPerRow', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to display in a row.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidestoshow',
			'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidestoscroll',
			'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Dots?', 'shopmarket-extensions' ),
			'name'			=> 'ca_dots',
			'description'	=> esc_html__( 'Check to show Dots.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Arrows?', 'shopmarket-extensions' ),
			'name'			=> 'ca_arrows',
			'description'	=> esc_html__( 'Check to show Arrows.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Responsive', 'shopmarket-extensions' ),
			'name'			=> 'ca_responsive',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new breakpoint', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'ca_res_breakpoint',
					'label'			=> esc_html__('Breakpoint', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter breakpoint.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidesperrow',
					'label'			=> esc_html__('slidesPerRow', 'shopmarket-extensions'),
					'type'			=> 'text',
					'value'			=> 1,
					'description'	=> esc_html__('Enter the number of items to display in a row.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoshow',
					'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoscroll',
					'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
					'admin_label'	=> true
				)
			)
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_products_carousel_vertical_tabs'] = array(
	'name' => esc_html__( 'Products Carousel Vertical Tabs', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Products Carousel Vertical Tabs', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Products Carousel Vertical Tabs Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'section_title',
			'label'			=> esc_html__('Section Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'description'	=> esc_html__('Enter section title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'bg_image',
			'type'			=> 'attach_image',
			'label'			=> esc_html__( 'Background Image', 'shopmarket-extensions' ),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Tabs', 'shopmarket-extensions' ),
			'name'			=> 'tabs',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new tab', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'title',
					'label'			=> esc_html__('Title', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'shortcode_tag',
					'label'			=> esc_html__( 'Shortcode', 'shopmarket-extensions' ),
					'type'			=> 'select',
					'options'		=> array(
						'featured_products'		=> esc_html__( 'Featured Products','shopmarket-extensions'),
						'sale_products'			=> esc_html__( 'On Sale Products','shopmarket-extensions'),
						'top_rated_products'	=> esc_html__( 'Top Rated Products','shopmarket-extensions'),
						'recent_products'		=> esc_html__( 'Recent Products','shopmarket-extensions'),
						'best_selling_products'	=> esc_html__( 'Best Selling Products','shopmarket-extensions'),
						'products'				=> esc_html__( 'Products','shopmarket-extensions'),
						'product_category'		=> esc_html__( 'Product Category','shopmarket-extensions')
					),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'per_page',
					'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of products to display.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'orderby',
					'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
					'value'			=> 'date',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'order',
					'label'			=> esc_html__('Order', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
					'value'			=> 'desc',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'template',
					'label'			=> esc_html__('Template', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter product template Default: content-product', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'product_id',
					'label'			=> esc_html__('Product IDs', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with Products Shortcode.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'category',
					'label'			=> esc_html__('Category', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter slug spearate by comma(,) Note: Only works with Product Category Shortcode.', 'shopmarket-extensions'),
					'admin_label'	=> true
				)
			)
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Infinite?', 'shopmarket-extensions' ),
			'name'			=> 'ca_infinite',
			'description'	=> esc_html__( 'Check to show Infinite Carousel.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'ca_slidestoshow',
			'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidestoscroll',
			'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Dots?', 'shopmarket-extensions' ),
			'name'			=> 'ca_dots',
			'description'	=> esc_html__( 'Check to show Dots.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Responsive', 'shopmarket-extensions' ),
			'name'			=> 'ca_responsive',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new breakpoint', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'ca_res_breakpoint',
					'label'			=> esc_html__('Breakpoint', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter breakpoint.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoshow',
					'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoscroll',
					'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
					'admin_label'	=> true
				)
			)
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_products_carousel_with_bg'] = array(
	'name' => esc_html__( 'Products Carousel with Image', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Products Carousel with Image', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Products Carousel with Image Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'shortcode_tag',
			'label'			=> esc_html__( 'Shortcode', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'featured_products'		=> esc_html__( 'Featured Products','shopmarket-extensions'),
				'sale_products'			=> esc_html__( 'On Sale Products','shopmarket-extensions'),
				'top_rated_products'	=> esc_html__( 'Top Rated Products','shopmarket-extensions'),
				'recent_products'		=> esc_html__( 'Recent Products','shopmarket-extensions'),
				'best_selling_products'	=> esc_html__( 'Best Selling Products','shopmarket-extensions'),
				'products'				=> esc_html__( 'Products','shopmarket-extensions'),
				'product_category'		=> esc_html__( 'Product Category','shopmarket-extensions')
			),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'per_page',
			'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of products to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'orderby',
			'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
			'value'			=> 'date',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'order',
			'label'			=> esc_html__('Order', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
			'value'			=> 'desc',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'template',
			'label'			=> esc_html__('Template', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter product template Default: content-product', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'product_id',
			'label'			=> esc_html__('Product IDs', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with Products Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'category',
			'label'			=> esc_html__('Category', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter slug spearate by comma(,) Note: Only works with Product Category Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Header Timer?', 'shopmarket-extensions' ),
			'name'			=> 'header_timer',
			'description'	=> esc_html__( 'Check to show Header Timer.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'timer_value',
			'label'			=> esc_html__('Timer Value', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the timer value.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'image',
			'type'			=> 'attach_image',
			'label'			=> esc_html__( 'Image', 'shopmarket-extensions' ),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Infinite?', 'shopmarket-extensions' ),
			'name'			=> 'ca_infinite',
			'description'	=> esc_html__( 'Check to show Infinite Carousel.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'ca_rows',
			'label'			=> esc_html__('rows', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of rows to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidesperrow',
			'label'			=> esc_html__('slidesPerRow', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to display in a row.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidestoshow',
			'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidestoscroll',
			'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Dots?', 'shopmarket-extensions' ),
			'name'			=> 'ca_dots',
			'description'	=> esc_html__( 'Check to show Dots.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Arrows?', 'shopmarket-extensions' ),
			'name'			=> 'ca_arrows',
			'description'	=> esc_html__( 'Check to show Arrows.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Responsive', 'shopmarket-extensions' ),
			'name'			=> 'ca_responsive',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new breakpoint', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'ca_res_breakpoint',
					'label'			=> esc_html__('Breakpoint', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter breakpoint.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidesperrow',
					'label'			=> esc_html__('slidesPerRow', 'shopmarket-extensions'),
					'type'			=> 'text',
					'value'			=> 1,
					'description'	=> esc_html__('Enter the number of items to display in a row.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoshow',
					'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoscroll',
					'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
					'admin_label'	=> true
				)
			)
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_products_carousel'] = array(
	'name' => esc_html__( 'Products Carousel', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Products Carousel', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Products Carousel Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'shortcode_tag',
			'label'			=> esc_html__( 'Shortcode', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'featured_products'		=> esc_html__( 'Featured Products','shopmarket-extensions'),
				'sale_products'			=> esc_html__( 'On Sale Products','shopmarket-extensions'),
				'top_rated_products'	=> esc_html__( 'Top Rated Products','shopmarket-extensions'),
				'recent_products'		=> esc_html__( 'Recent Products','shopmarket-extensions'),
				'best_selling_products'	=> esc_html__( 'Best Selling Products','shopmarket-extensions'),
				'products'				=> esc_html__( 'Products','shopmarket-extensions'),
				'product_category'		=> esc_html__( 'Product Category','shopmarket-extensions')
			),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'per_page',
			'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of products to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'orderby',
			'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
			'value'			=> 'date',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'order',
			'label'			=> esc_html__('Order', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
			'value'			=> 'desc',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'template',
			'label'			=> esc_html__('Template', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter product template Default: content-product', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'product_id',
			'label'			=> esc_html__('Product IDs', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with Products Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'category',
			'label'			=> esc_html__('Category', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter slug spearate by comma(,) Note: Only works with Product Category Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Header Navigation?', 'shopmarket-extensions' ),
			'name'			=> 'header_custom_nav',
			'description'	=> esc_html__( 'Check to show Custom Navigation.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Infinite?', 'shopmarket-extensions' ),
			'name'			=> 'ca_infinite',
			'description'	=> esc_html__( 'Check to show Infinite Carousel.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'ca_rows',
			'label'			=> esc_html__('rows', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of rows to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidesperrow',
			'label'			=> esc_html__('slidesPerRow', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to display in a row.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidestoshow',
			'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ca_slidestoscroll',
			'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Dots?', 'shopmarket-extensions' ),
			'name'			=> 'ca_dots',
			'description'	=> esc_html__( 'Check to show Dots.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Arrows?', 'shopmarket-extensions' ),
			'name'			=> 'ca_arrows',
			'description'	=> esc_html__( 'Check to show Arrows.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Responsive', 'shopmarket-extensions' ),
			'name'			=> 'ca_responsive',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new breakpoint', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'ca_res_breakpoint',
					'label'			=> esc_html__('Breakpoint', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter breakpoint.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidesperrow',
					'label'			=> esc_html__('slidesPerRow', 'shopmarket-extensions'),
					'type'			=> 'text',
					'value'			=> 1,
					'description'	=> esc_html__('Enter the number of items to display in a row.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoshow',
					'label'			=> esc_html__('slidesToShow', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to display.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'ca_res_slidestoscroll',
					'label'			=> esc_html__('slidesToScroll', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of items to scroll.', 'shopmarket-extensions'),
					'admin_label'	=> true
				)
			)
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_products_isotope'] = array(
	'name' => esc_html__( 'Products Isotope', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Products Isotope', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Products Isotope Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'pre_title',
			'label'			=> esc_html__('Pre Title', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter pre title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'style',
			'label'			=> esc_html__( 'Style', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'style-1'		=> esc_html__('Style 1', 'shopmarket-extensions'),
				'style-2'		=> esc_html__('Style 2', 'shopmarket-extensions')
			),
			'description'	=> esc_html__( 'Select style for products.', 'shopmarket-extensions' ),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'shortcode_tag',
			'label'			=> esc_html__( 'Shortcode', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'featured_products'		=> esc_html__( 'Featured Products','shopmarket-extensions'),
				'sale_products'			=> esc_html__( 'On Sale Products','shopmarket-extensions'),
				'top_rated_products'	=> esc_html__( 'Top Rated Products','shopmarket-extensions'),
				'recent_products'		=> esc_html__( 'Recent Products','shopmarket-extensions'),
				'best_selling_products'	=> esc_html__( 'Best Selling Products','shopmarket-extensions'),
				'products'				=> esc_html__( 'Products','shopmarket-extensions'),
				'product_category'		=> esc_html__( 'Product Category','shopmarket-extensions')
			),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'per_page',
			'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of products to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'orderby',
			'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
			'value'			=> 'date',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'order',
			'label'			=> esc_html__('Order', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
			'value'			=> 'desc',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'product_id',
			'label'			=> esc_html__('Product IDs', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with Products Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'category',
			'label'			=> esc_html__('Category', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter slug spearate by comma(,) Note: Only works with Product Category Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Header Timer?', 'shopmarket-extensions' ),
			'name'			=> 'header_timer',
			'description'	=> esc_html__( 'Check to show Header Timer.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'timer_title',
			'label'			=> esc_html__('Timer Title', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the timer title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'timer_value',
			'label'			=> esc_html__('Timer Value', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the timer value.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'action_text',
			'label'			=> esc_html__('Action Text', 'shopmarket-extensions'),
			'type'			=> 'text',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'action_link',
			'label'			=> esc_html__('Action Link', 'shopmarket-extensions'),
			'type'			=> 'text',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_products_tabs'] = array(
	'name' => esc_html__( 'Products Tabs', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Products Tabs', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Products Tabs Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'section_title',
			'label'			=> esc_html__('Section Title', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter section title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'header_nav_align',
			'label'			=> esc_html__( 'Header Align', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'justify-content-start'		=> esc_html__( 'Start', 'shopmarket-extensions'),
				'justify-content-center'	=> esc_html__( 'Center', 'shopmarket-extensions'),
				'justify-content-end'		=> esc_html__( 'End', 'shopmarket-extensions'),
			),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'group',
			'label'			=> esc_html__( 'Tabs', 'shopmarket-extensions' ),
			'name'			=> 'tabs',
			'description'	=> '',
			'options'		=> array(
				'add_text'			=> esc_html__( 'Add new tab', 'shopmarket-extensions' )
			),
			'params' => array(
				array(
					'name'			=> 'title',
					'label'			=> esc_html__('Title', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'shortcode_tag',
					'label'			=> esc_html__( 'Shortcode', 'shopmarket-extensions' ),
					'type'			=> 'select',
					'options'		=> array(
						'featured_products'		=> esc_html__( 'Featured Products','shopmarket-extensions'),
						'sale_products'			=> esc_html__( 'On Sale Products','shopmarket-extensions'),
						'top_rated_products'	=> esc_html__( 'Top Rated Products','shopmarket-extensions'),
						'recent_products'		=> esc_html__( 'Recent Products','shopmarket-extensions'),
						'best_selling_products'	=> esc_html__( 'Best Selling Products','shopmarket-extensions'),
						'products'				=> esc_html__( 'Products','shopmarket-extensions'),
						'product_category'		=> esc_html__( 'Product Category','shopmarket-extensions')
					),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'per_page',
					'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of products to display.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'columns',
					'label'			=> esc_html__('Columns', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter the number of columns to display.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'orderby',
					'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
					'value'			=> 'date',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'order',
					'label'			=> esc_html__('Order', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
					'value'			=> 'desc',
					'admin_label'	=> true
				),
				array(
					'name'			=> 'template',
					'label'			=> esc_html__('Template', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter product template Default: content-product', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'product_id',
					'label'			=> esc_html__('Product IDs', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with Products Shortcode.', 'shopmarket-extensions'),
					'admin_label'	=> true
				),
				array(
					'name'			=> 'category',
					'label'			=> esc_html__('Category', 'shopmarket-extensions'),
					'type'			=> 'text',
					'description'	=> esc_html__('Enter slug spearate by comma(,) Note: Only works with Product Category Shortcode.', 'shopmarket-extensions'),
					'admin_label'	=> true
				)
			)
		),
		array(
			'name'			=> 'action_text',
			'label'			=> esc_html__('Action Text', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'action_link',
			'label'			=> esc_html__('Action Link', 'shopmarket-extensions'),
			'type'			=> 'text',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_products_with_image'] = array(
	'name' => esc_html__( 'Products with Image', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Products with Image', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Products with Image Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter title.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'shortcode_tag',
			'label'			=> esc_html__( 'Shortcode', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'featured_products'		=> esc_html__( 'Featured Products','shopmarket-extensions'),
				'sale_products'			=> esc_html__( 'On Sale Products','shopmarket-extensions'),
				'top_rated_products'	=> esc_html__( 'Top Rated Products','shopmarket-extensions'),
				'recent_products'		=> esc_html__( 'Recent Products','shopmarket-extensions'),
				'best_selling_products'	=> esc_html__( 'Best Selling Products','shopmarket-extensions'),
				'products'				=> esc_html__( 'Products','shopmarket-extensions'),
				'product_category'		=> esc_html__( 'Product Category','shopmarket-extensions')
			),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'per_page',
			'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of products to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'orderby',
			'label'			=> esc_html__('Orderby', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter orderby.', 'shopmarket-extensions'),
			'value'			=> 'date',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'order',
			'label'			=> esc_html__('Order', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter order.', 'shopmarket-extensions'),
			'value'			=> 'desc',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'columns',
			'label'			=> esc_html__('Columns', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of columns to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'template',
			'label'			=> esc_html__('Template', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter product template Default: content-product', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'product_id',
			'label'			=> esc_html__('Product IDs', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with Products Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'category',
			'label'			=> esc_html__('Category', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter slug spearate by comma(,) Note: Only works with Product Category Shortcode.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'action_text',
			'label'			=> esc_html__('Action Text', 'shopmarket-extensions'),
			'type'			=> 'text',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'action_link',
			'label'			=> esc_html__('Action Link', 'shopmarket-extensions'),
			'type'			=> 'text',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'description',
			'label'			=> esc_html__('Description', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'image',
			'type'			=> 'attach_image',
			'label'			=> esc_html__( 'Image', 'shopmarket-extensions' ),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_recent_posts_with_categories'] = array(
	'name' => esc_html__( 'Recent Posts with Categories', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Recent Posts with Categories', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Recent Posts with Categories Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'section_title',
			'label'			=> esc_html__('Title', 'shopmarket-extensions'),
			'type'			=> 'text',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'description',
			'label'			=> esc_html__('Description', 'shopmarket-extensions'),
			'type'			=> 'textarea',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'post_choice',
			'label'			=> esc_html__( 'Choice', 'shopmarket-extensions' ),
			'type'			=> 'select',
			'options'		=> array(
				'recent'		=> esc_html__('Recent', 'shopmarket-extensions'),
				'random'		=> esc_html__('Random', 'shopmarket-extensions'),
				'specific'		=> esc_html__('Specific', 'shopmarket-extensions')
			),
			'description'	=> esc_html__( 'Select choice for posts.', 'shopmarket-extensions' ),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'ids',
			'label'			=> esc_html__('IDs', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter id spearate by comma(,) Note: Only works with specific choice.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'limit',
			'label'			=> esc_html__('Limit', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of posts to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'type'			=> 'checkbox',
			'label'			=> esc_html__( 'Show Read More', 'shopmarket-extensions' ),
			'name'			=> 'show_read_more',
			'description'	=> esc_html__( 'Check to show Read More.', 'shopmarket-extensions' ),
			'options'		=> array( 'true' => esc_html__( 'Enable', 'shopmarket-extensions' ) ),
		),
		array(
			'name'			=> 'cat_limit',
			'label'			=> esc_html__('Category Limit', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter the number of category to display.', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'cat_slugs',
			'label'			=> esc_html__('Category Slugs', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('Enter slug spearate by comma(,)', 'shopmarket-extensions'),
			'admin_label'	=> true
		),
		array(
			'name'			=> 'el_class',
			'label'			=> esc_html__('Extra class name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'description'	=> esc_html__('If you wish to style particular content element differently, please add a class name to this field and refer to it in your custom CSS file.', 'shopmarket-extensions')
		)
	),
);

$shortcode_params['shopmarket_team_member'] = array(
	'name' => esc_html__( 'Team Member', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Team Member', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Team Member Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'name'			=> 'name',
			'label'			=> esc_html__('Name', 'shopmarket-extensions'),
			'type'			=> 'text',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'designation',
			'label'			=> esc_html__('Designation', 'shopmarket-extensions'),
			'type'			=> 'text',
			'admin_label'	=> true
		),
		array(
			'name'			=> 'image',
			'type'			=> 'attach_image',
			'label'			=> esc_html__( 'Image', 'shopmarket-extensions' ),
			'admin_label'	=> true
		)
	),
);

$shortcode_params['shopmarket_terms'] = array(
	'name' => esc_html__( 'Terms', 'shopmarket-extensions' ),
	'description' => esc_html__( 'Adds a shortcode for get_terms. Used to get terms including categories, product categories, etc.', 'shopmarket-extensions' ),
	'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
	'title' => esc_html__( 'Terms Settings', 'shopmarket-extensions' ),
	'is_container' => true,
	'params' => array(
		array(
			'type'			=> 'text',
			'label'			=> esc_html__( 'Taxonomy', 'shopmarket-extensions' ),
			'name'			=> 'taxonomy',
			'description'	=> esc_html__( 'Taxonomy name, or comma-separated taxonomies, to which results should be limited.', 'shopmarket-extensions' ),
			'value'			=> 'category',
			'admin_label'	=> true
		),
		array(
			'type'			=> 'text',
			'label'			=> esc_html__( 'Order By', 'shopmarket-extensions' ),
			'name'			=> 'orderby',
			'description'	=> esc_html__( 'Field(s) to order terms by. Accepts term fields (\'name\', \'slug\', \'term_group\', \'term_id\', \'id\', \'description\'). Defaults to \'name\'.', 'shopmarket-extensions' ),
			'value'			=> 'name'
		),
		array(
			'type'			=> 'text',
			'label'			=> esc_html__( 'Order', 'shopmarket-extensions' ),
			'name'			=> 'order',
			'description'	=> esc_html__( 'Whether to order terms in ascending or descending order. Accepts \'ASC\' (ascending) or \'DESC\' (descending). Default \'ASC\'.', 'shopmarket-extensions' ),
			'value'			=> 'ASC'
		),
		array(
			'type'			=> 'text',
			'label'			=> esc_html__( 'Hide Empty ?', 'shopmarket-extensions' ),
			'name'			=> 'hide_empty',
			'description'	=> esc_html__( 'Whether to hide terms not assigned to any posts. Accepts 1 or 0. Default 0.', 'shopmarket-extensions' ),
			'value'			=> '0'
		),
		array(
			'type'			=> 'text',
			'label'			=> esc_html__( 'Include IDs', 'shopmarket-extensions' ),
			'name'			=> 'include',
			'description'	=> esc_html__( 'Comma-separated string of term ids to include.', 'shopmarket-extensions' ),
		),
		array(
			'type'			=> 'text',
			'label'			=> esc_html__( 'Exclude IDs', 'shopmarket-extensions' ),
			'name'			=> 'exclude',
			'description'	=> esc_html__( 'Comma-separated string of term ids to exclude. If Include is non-empty, Exclude is ignored.', 'shopmarket-extensions' ),
		),
		array(
			'type'			=> 'text',
			'label'			=> esc_html__( 'Number', 'shopmarket-extensions' ),
			'name'			=> 'number',
			'description'	=> esc_html__( 'Maximum number of terms to return. Accepts 0 (all) or any positive number. Default 0 (all).', 'shopmarket-extensions' ),
			'value'			=> '0',
		),
		array(
			'type'			=> 'text',
			'label'			=> esc_html__( 'Offset', 'shopmarket-extensions' ),
			'name'			=> 'offset',
			'description'	=> esc_html__( 'The number by which to offset the terms query.', 'shopmarket-extensions' ),
			'value'			=> '0',
		),
		array(
			'type'			=> 'text',
			'label'			=> esc_html__( 'Name', 'shopmarket-extensions' ),
			'name'			=> 'name',
			'description'	=> esc_html__( 'Name or comma-separated string of names to return term(s) for.', 'shopmarket-extensions' ),
		),
		array(
			'type'			=> 'text',
			'label'			=> esc_html__( 'Slug', 'shopmarket-extensions' ),
			'name'			=> 'slug',
			'description'	=> esc_html__( 'Slug or comma-separated string of slugs to return term(s) for.', 'shopmarket-extensions' ),
		),
		array(
			'type'			=> 'text',
			'label'			=> esc_html__( 'Hierarchical', 'shopmarket-extensions' ),
			'name'			=> 'hierarchical',
			'description'	=> esc_html__( 'Whether to include terms that have non-empty descendants. Accepts 1 (true) or 0 (false). Default 1 (true)', 'shopmarket-extensions' ),
			'value'			=> '1',
		),
		array(
			'type'			=> 'text',
			'label'			=> esc_html__( 'Child Of', 'shopmarket-extensions' ),
			'name'			=> 'child_of',
			'description'	=> esc_html__( 'Term ID to retrieve child terms of. If multiple taxonomies are passed, child_of is ignored. Default 0.', 'shopmarket-extensions' ),
			'value'			=> '0',
		),
		array(
			'type'			=> 'text',
			'label'			=> esc_html__( 'Include "Child Of" term ?', 'shopmarket-extensions' ),
			'name'			=> 'include_parent',
			'description'	=> esc_html__( 'Include "Child Of" term in the terms list. Accepts 1 (yes) or 0 (no). Default 1.', 'shopmarket-extensions' ),
			'value'			=> '1',
		),
		array(
			'type'			=> 'text',
			'label'			=> esc_html__( 'Parent', 'shopmarket-extensions' ),
			'name'			=> 'parent',
			'description'	=> esc_html__( 'Parent term ID to retrieve direct-child terms of.', 'shopmarket-extensions' ),
			'value'			=> '',
		)
	),
);

if ( class_exists( 'RevSlider' ) ) {
	$revsliders = array();
	
	$slider = new RevSlider();
	$arrSliders = $slider->getArrSliders();

	if ( $arrSliders ) {
		foreach ( $arrSliders as $slider ) {
			$revsliders[ $slider->getAlias() ] = $slider->getTitle();
		}
	} else {
		$revsliders[0] = esc_html__( 'No sliders found', 'shopmarket-extensions' );
	}

	$shortcode_params['rev_slider'] = array(
		'name' => esc_html__( 'Revolution Slider', 'shopmarket-extensions' ),
		'description' => esc_html__( 'Select your Revolution Slider.', 'shopmarket-extensions' ),
		'category' => esc_html__( 'shopmarket Elements', 'shopmarket-extensions' ),
		'title' => esc_html__( 'Revolution Slider Settings', 'shopmarket-extensions' ),
		'is_container' => true,
		'params' => array(
			array(
				'name'			=> 'alias',
				'label'			=> esc_html__('Revolution Slider', 'shopmarket-extensions' ),
				'type'			=> 'select',
				'options'		=> $revsliders,
				'admin_label'	=> true
			)
		),
	);
}

$shortcode_params = apply_filters( 'shopmarket_kc_map_shortcode_params', $shortcode_params );

$kc->add_map( $shortcode_params );