<?php

if ( ! function_exists( 'shopmarket_jumbotron_element' ) ) {

	function shopmarket_jumbotron_element( $atts, $content = null ){

		extract(shortcode_atts(array(
			'title'				=> '',
			'sub_title'			=> '',
			'image'				=> '',
		), $atts));

		$args = array(
			'title'			=> $title,
			'sub_title'		=> $sub_title,
			'image'			=> $image,
		);

		$html = '';
		if( function_exists( 'shopmarket_jumbotron' ) ) {
			ob_start();
			shopmarket_jumbotron( $args );
			$html = ob_get_clean();
		}

		return $html;
	}

}

add_shortcode( 'shopmarket_jumbotron' , 'shopmarket_jumbotron_element' );