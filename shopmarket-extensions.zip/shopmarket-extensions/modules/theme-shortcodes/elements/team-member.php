<?php

if ( ! function_exists( 'shopmarket_team_member_element' ) ) {

	function shopmarket_team_member_element( $atts, $content = null ){

		extract(shortcode_atts(array(
			'name'			=> '',
			'designation'	=> '',
			'image'			=> ''
		), $atts));

		$args = array(
			'name'			=> $name,
			'designation'	=> $designation,
			'image'			=> isset( $image ) && intval( $image ) ? wp_get_attachment_image_src( $image, 'full' ) : array( '//placehold.it/290x301', '290', '301' ),
		);

		$html = '';
		if( function_exists( 'shopmarket_team_member' ) ) {
			ob_start();
			shopmarket_team_member( $args );
			$html = ob_get_clean();
		}

		return $html;
	}

}

add_shortcode( 'shopmarket_team_member' , 'shopmarket_team_member_element' );