<?php

if ( ! function_exists( 'shopmarket_media_single_banner_element' ) ) {

	function shopmarket_media_single_banner_element( $atts, $content = null ){

		extract(shortcode_atts(array(
			'section_title'	=> '',
			'description'	=> '',
			'action_text'	=> '',
			'action_link'	=> '#',
			'image'			=> '',
			'media_align'	=> '',
			'el_class'		=> ''
		), $atts));

		$el_class = empty( $media_align ) ? $el_class : $media_align . ' ' . $el_class;

		$args = array(
			'section_title'	=> $section_title,
			'description'	=> $description,
			'action_text'	=> $action_text,
			'action_link'	=> $action_link,
			'image'			=> isset( $image ) && intval( $image ) ? wp_get_attachment_image_src( $image, 'full' ) : '',
			'section_class'	=> $el_class,
		);

		$html = '';
		if( function_exists( 'shopmarket_media_single_banner' ) ) {
			ob_start();
			shopmarket_media_single_banner( $args );
			$html = ob_get_clean();
		}

		return $html;
	}

}

add_shortcode( 'shopmarket_media_single_banner' , 'shopmarket_media_single_banner_element' );